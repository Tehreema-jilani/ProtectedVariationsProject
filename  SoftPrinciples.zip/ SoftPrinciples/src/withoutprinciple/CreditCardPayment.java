/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package withoutprinciple;

/**
 *
 * @author Tehreema
 */
  
public class CreditCardPayment {
    public boolean processPayment(double amount) {
        System.out.println("Payment of $" + amount + " processed through Credit Card.");
        return true;  
    }
}
