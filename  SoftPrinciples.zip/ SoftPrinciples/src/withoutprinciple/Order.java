/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package withoutprinciple;

/**
 *
 * @author Tehreema
 */
  
public class Order {
    private String orderId;
    private double amount;

    public Order(String orderId, double amount) {
        this.orderId = orderId;
        this.amount = amount;
    }

    public void processOrder() {
        CreditCardPayment creditCardPayment = new CreditCardPayment();  
        if (creditCardPayment.processPayment(amount)) {
            System.out.println("Order " + orderId + " processed successfully.");
        } else {
            System.out.println("Order " + orderId + " failed to process.");
        }
    }
}

