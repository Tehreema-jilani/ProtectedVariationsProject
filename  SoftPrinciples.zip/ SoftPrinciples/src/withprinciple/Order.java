/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package withprinciple;

/**
 *
 * @author Tehreema
 */
 
public class Order {
    private String orderId;
    private double amount;
    private PaymentProcessor paymentProcessor;  

    public Order(String orderId, double amount, PaymentProcessor paymentProcessor) {
        this.orderId = orderId;
        this.amount = amount;
        this.paymentProcessor = paymentProcessor;
    }

    public void processOrder() {
        if (paymentProcessor.processPayment(amount)) {
            System.out.println("Order " + orderId + " processed successfully.");
        } else {
            System.out.println("Order " + orderId + " failed to process.");
        }
    }
}

