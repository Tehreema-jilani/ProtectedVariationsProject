/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package withprinciple;

/**
 *
 * @author Tehreema
 */
  
public class Main {
    public static void main(String[] args) {
         
        PaymentProcessor paymentProcessor = new CreditCardPayment();
        Order order = new Order("ORD001", 100.0, paymentProcessor);
        order.processOrder();  
    }
}
